﻿#Joe Snider
#6/10
#
#Interface for the custom phasespace tracker

import viz
import vizshape

class PhaseSpaceMultiClass(viz.VizSensor):
	
	def __init__(self, what):
		viz.VizSensor.__init__(self, what)

	######These commands affect the individual marker
	
	def status(self):
		print "Call status"
		self.command(1)
		
	#insert markers into this object
	def addMarkers(self, *markers):
		for m in markers:
			self.command(5, '', m)
			
	#set this marker to be a rigid body
	def setRigidMarker(self):
		self.command(6)
		
	#set this marker to be a point marker
	def setPointMarker(self):
		self.command(7)
		
	####These commands affect all markers
	#set the frequency
	def setFrequency(self, frequency):
		self.command(10, '', frequency)
		
	#set as a slave
	def setSlave(self):
		self.command(11, '', int(0x0001))
		
	#set the address of the server
	#address should be a string, e.g., '111.222.333.444'
	def setServerAddress(self, address):
		self.command(9, address)
		
	#start streaming (currently cannot cleanly stop)
	def startStreaming(self):
		self.command(8)
		
	#set the offset
	def setOffset(self, x, y, z):
		self.command(3, '', x, y, z)
	def setOffsetList(self, x):
		self.command(3, '', x[0], x[1], x[2])
		
	#set this marker's current position as the origin
	def setOrigin(self):
		self.command(4)
		
	#set the scale, all equal to 0.001 is approximately meters
	def setScale(self, x, y, z):
		self.command(2, '', x, y, z)
		
	###############High speed recording
	#the trials thing is for compatability with the logger
	def startRecording(self, trials=0):
		self.synchronize()
		self.command(100)
		
	def stopRecording(self):
		self.command(101)
		
	#dump the recorded data to the file fileName
	def dumpRecording(self, fileName):
		self.command(102, fileName)
		
	def clearRecording(self):
		self.command(103)
		
	#synchronize the time with the input clock
	def synchronize(self):
		self.command(104, '', viz.tick())
	def synchronizeTime(self, time):
		self.command(104, '', time)

	
viz.upgradeSensor('PhaseSpaceMulti_joe.dls',PhaseSpaceMultiClass)
def addPhaseSpaceMulti():
	return viz.add('PhaseSpaceMulti_joe.dls')
	
if __name__ == '__main__':
	viz.go()
	vizshape.addAxes()
	
	PS1 = addPhaseSpaceMulti()
	PS1.addMarkers(0, 1, 2, 3, 4, 5, 6)
	PS1.setPointMarker()
	PS1.setServerAddress('128.174.14.227')
	PS1.setFrequency(240)
	PS1.setScale(0.001, 0.001, 0.001)
	PS1.setSlave()
	#PS1.startStreaming()

	viz.setOption('viz.model.apply_collada_scale',1)
	
	
	ball = viz.add('white_ball.wrl')
	ball.color(viz.WHITE)
	#ball.setPosition(0,2,0)
	#ball.alpha = 0
	#ball.setScale(0)
	ojo = viz.addChild('sky_day.osgb')
	print PS1
	viz.link(PS1, ball)

	PS2 = addPhaseSpaceMulti()
	PS2.addMarkers(7, 8, 9, 10, 11, 12)
	PS2.setPointMarker()

	PS2.setServerAddress('128.174.14.227')
	PS2.setFrequency(240)
	PS2.setScale(0.001, 0.001, 0.001)
	PS2.setSlave()
	PS1.startStreaming()
	PS2.startStreaming()
	
	ball1 = viz.add('white_ball.wrl')
	ball1.color(viz.WHITE)
	#ball1.alpha = 0
	#ball1.setScale(0)
	#ball1.setPosition(0,2,0)
	
	print PS2
	viz.link(PS2, ball1)


	water_level = 0
	
	paddle = viz.add('paddle/newOar.dae')
	paddle.setEuler( [ 90, 0, 0 ] )
	#viz.link(ball, paddle)
	v_x = [1, 0, 0]
	global v_paddle 
	v_paddle_last = paddle.getEuler()
	Trans = vizmat.Transform()
	global prev_p0 
	prev_p0 = ball.getPosition()
	global prev_p1
	prev_p1 = ball1.getPosition()
	def TestRecording():
		print ball.getPosition()
		print ball1.getPosition()

	def RotatePaddle():
		'''
		
		'''		
		p0 = ball.getPosition();
		p1 = ball1.getPosition();
		v_true = [p1[0] - p0[0],p1[1] - p0[1],p1[2] - p0[2] ]
		position_true = [(p1[0] + p0[0])/2,(p1[1] + p0[1])/2,(p1[2] + p0[2])/2]
		#delta_y = paddle.getPosition()
		position_true[1] *= 1.5
		#v_paddle = 
		Trans.makeVecRotVec(v_x, v_true)
		euler = Trans.getEuler()
		paddle.setEuler(euler)
		paddle.setPosition(position_true)
		prev_p0 = p0
		prev_p1 = p1
	import vizact
	vizact.onkeydown(' ', TestRecording)
	vizact.ontimer(0.01, RotatePaddle)
	'''#test sending the ttl
	parallel_port = 0x037f
	import sendPulse
	S1 = sendPulse.SendPulse(parallel_port)
	def TestPulse():
		print "sending a 1",str(viz.tick())
		S1.sendPulse(1)
	vizact.onkeychar('t', TestPulse)'''

