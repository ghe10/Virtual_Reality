The project is built by Unity3D with Oculus.
The R key is used to enable/disable the rotate tracking
The P key is used to enable/disable the position tracking
The fist time we press S key, all three balls look the same size(will not disappear).
Then S key is used to switch on/off the appearance of three balls.

Thanks for your evaluation!